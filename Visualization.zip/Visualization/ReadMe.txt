launch chrome with --allow-file-access-from-files option or set up a web server to watch the result.

(left click)/(up arrow) to resume simulation.
left arrow to display previous graph.
right arrow to display next graph.
